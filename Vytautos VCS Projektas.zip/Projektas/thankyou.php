<?php
ini_set('display_errors', '1');
include_once 'headeroff.php';
?>

<div class="hero" style="padding: 100px 20px">
<h2>Dėkojame. Jūsų žinutė gauta. Netrukus su Jumis susisieksime.</h2>
<p class="text-muted"><a href="index.php" style="color: var(--yellow); text-decoration: none;">Grįžti į pradinį puslapį</a></p>
</div>

<?php
include_once('footer.php');
?>