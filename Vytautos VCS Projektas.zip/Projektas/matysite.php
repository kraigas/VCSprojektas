<?php
include_once 'headeroff.php';
ini_set('display_errors', '1');
include('src/conn.php');
?>

<section class="kalnedorius">

    <h2>Mus galite pamatyti</h2>
    <table class="tbl-matysite">
        <tr class="tr-header">
            <th>Data</th>
            <th>Renginys</th>
        </tr>
    
    <?php
    $date_now = date('Y-m-d');
    while ($rows = mysqli_fetch_assoc($result)) {
        if ($rows['Data_Nuo'] >= $date_now) {
            echo
            '<tr>
                <td>' . $rows["Data_Nuo"] . '</td>
                <td class="td-ren">' . $rows["Ren_Pavadinimas"] . '</td>
            </tr>';
        } 
    }
?>

</table>
</section>

<?php
include_once 'footer.php'
?>