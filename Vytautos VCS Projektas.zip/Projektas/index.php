<?php
include_once('header.php');
//ini_set('display_errors', '1');
require __DIR__ . '/src/app.php';
?>

	<div class="parallax bg1 hero">
		<div class="hero-content">
			<div class="intro-lead-in">Jus sveikina</div>
			<div class="intro-heading">Gyvosios istorijos klubas „Leitgiris“</div>
		</div>
	</div>

	<!-- veikla -->
	<div class="karyba" id="apie">
		<div class="kryptis">
			<div class="number">1</div>
			<h2>Karyba</h2>
			<p class="text-muted">Leitgiris rekonstruoja IX-XIII a. baltų karius. Pagrindinis mūsų tikslas - atkurti karingųjų protėvių išvaizdą, karybos kultūrą, papročius ir žinoma - kovas. Naudojame ginklų ir šarvų kopijas, kuriais kovėsi lietuviai, jotvingiai, kuršiai, aukštaičiai, žemaičiai, skalviai, sėliai ir kitos baltų gentys.</p>
		</div>
	</div>
	<div class="amatai">
		<div class="kryptis">
			<div class="number">2</div>
			<h2>Amatai</h2>
			<p class="text-muted">Klube aktyviai vystomi archajiški baltų amatai - odos apdirbimas, audimas, siuvimas, pluošto dažymas, juostų vijimas, nėrimas adata, medžio darbai, kalvystė ir daugelis kitų. Stengiamės savo rankomis atkurti senovės baltų buities reikmenis, drabužius, šarvus ir net ginklus. Nepamirštame ir midaus virimo bei kitų senovinės virtuvės gėrybių.</p>
		</div>
	</div>
	<div class="edukacijos">
		<div class="kryptis">
			<div class="number">3</div>
			<h2>Edukacijos</h2>
			<p class="text-muted">Istorinės edukacijos programos skirtos gyvai pristatyti ankstyvųjų viduramžių laikotarpį, kuomet formavosi Lietuva kaip valstybė. Pristatome senovės baltų karybą, senovines pramogas ir žaidimus, įvairius amatus ir buitį. Kiekvienas gali pasirinkti tai kas jį labiausiai domina.</p>
		</div>
	</div>
	<div class="apie">
		<div class="kryptis">
			<div class="number">4</div>
			<h2>Klubas</h2>
			<p class="text-muted">Klubas įkurtas 2012 m. gruodžio 20 d., tačiau jo senbuviai istorine rekonstrukcija domisi ir užsiiminėja jau daugiau nei 10 metų. Leitgirio narius suvienijo senobinis leičių luomas, todėl nenuostabu, kad klubo pasirinktas istorinės rekonstrukcijos laikotarpis yra XII-XIII a., kuomet Lietuva pradėjo žengti savo pirmuosius kaip didžios valstybės žingsnius ir užgimė pirmieji leičiai.</p>
		</div>
	</div>
	<div class="straipsniai">
		<div class="kryptis">
			<div class="number">5</div>
			<h2>Straipsniai</h2>
			<p class="text-muted">Viduramžių Lietuvos istorija taip žavi mus, kad istorinė rekonstrukcija tapo didele kiekvieno klubo nario dalimi ir gyvenimo būdu. Ilgi žiemos vakarai skirti tikslinei literatūrai ir rankdarbiams. Įgytos žinios ir patirtys kartais virsta ir klubo leičių straipsniais, kuriais ir norime pasidalinti.</p>
			<!-- Trigger/Open The Modal -->
			<input name="submit" type="submit" class="modalBtn" value="Straipsniai">
			<!-- The Modal -->
			<div class="modal">
				<!-- Modal content -->
				<div class="modal-content">
					<span class="close">&times;</span>
                    <h3>Teorija, moksliniai ir pažintiniai straipsniai</h3>   
                    <ul>
                    	<li><a href="#">Plokšteliniai šarvai. Lameliaras</a></li>
                    	<li><a href="#" target="_blank">Baltų genčių ribos (hidronimų pagrindu)</a></li>
                    	<li><a href="#">Keistieji viduramžiai: pasaulis be bulvių</a></li>
                    	<li><a href="s#">Senojo ir vidurinio geležies amžiaus skydai Lietuvoje</a></li>
                    	<li><a href="#">Lietuvos didžiojo kunigaikščio leičiai XIII–XVI a.: Lietuvių ankstyvojo feodalizmo visuomenės tyrimas</a></li>
                    	<li><a href="#">IX a. Tiro durpyno lobis</a></li>
                    	<li><a href="#">XIII a. Kunigaikščio kariaunos karys iš Gardino</a></li>
                    </ul>

                    <h3>Baltų mitologija, religija ir pasaulėžiūra</h3>
                    <p><a href="#">Gyvybės medis. Tarptautinis ir baltiškasis įvaizdžio aspektai</a></p>

                    <h3>Pasidaryk pats</h3>
                    <ul>
                    	<li><a href="#">Dažinė mėlžolė: auginimas</a></li>
                    	<li><a href="#">Mezgimas adata</a></li>
                    	<li><a href="#">Deguto varymas</a></li>
                    	<li><a href="#">Vytinės juostelės audimas II: rinktinis raštas</a></li>
                    	<li><a href="#">Kimštinis pošarvis</a></li>
                    	<li><a href="#">Midaus gamyba</a></li>
                    	<li><a href="#">Vytinės juostelės audimas</a></li>								
                    </ul>
				</div>
			</div>
		</div>
	</div>
	<div class="parama">
		<div class="kryptis">
			<div class="number">6</div>
			<h2>Parama mūsų veiklai</h2>
			<p class="text-muted">XXI amžiaus tempas gali būti per greitas ir Jūs tiesiog negalite skirti laiko mums ar mūsų veiklai, tačiau jei Jūs norite nors kaip nors prisidėti prie mūsų veiklos, tai galite skirti mūsų veiklai paramą! Ačiū Jums</p>
			<!-- Trigger/Open The Modal -->
			<input name="submit" type="submit" class="modalBtn" value="Parama">
			<!-- The Modal -->
			<div class="modal">
				<!-- Modal content -->
				<div class="modal-content">
					<span class="close">&times;</span>
					<h3>REKVIZITAI:</h3>
					<ul>
						<li>Paramos gavėjas – Gyvosios istorijos klubas "Leitgiris"</li>
						<li>Paramos gavėjo kodas – 302939965</li>
						<li>Adresas – Bendorėlių 1-oji al. 48, LT-14196, Bendoriai, Vilniaus r. sav.</li>
						<li>Banko sąskaita LT05 7300 0101 3417 4634</li>
						<li>Bankas „SWEDBANK“</li>
					</ul>
					<div><br>Taip pat galite užpildyti prašymą paskirti 2 proc. savo pajamų mokesčio, kurį galite rasti <a href="https://www.vmi.lt/cms/gpm-dalis-paramai" target="_blank">Valstybinės mokesčių inspekcijos puslapyje</a>.<br>
					Dėkojame!</div>
				</div>
			</div>
		</div>
	</div>

	<!-- social -->
	<div class="social">
		<div class="intro-lead-in">Bendraukime</div>
		<div class="social-intro-lead-in">Sekite mus socialiniame tinkle facebook!</div>
		<a href="https://www.facebook.com/Leitgiris" class="btn-sekti" target="_blank">Sekti</a>
	</div>

	<!-- counteris -->
	<div class="parallax bg2 statistika">
		<div class="overlay">
		<div class="stat-flex">
			<div class="stat">
				<span class="count">14</span>
				<div class="st-txt">Narių</div>
			</div>
			<div class="stat">
				<span class="count">5</span>
				<div class="st-txt">Šeiminykščių</div>
			</div>
			<div class="stat">
				<span class="count">120</span>
				<div class="st-txt">Sudalyvauta renginių</div>
			</div>
			<div class="stat">
				<span class="count">15</span>
				<div class="st-txt">Straipsnių</div>
			</div>
		</div>
		</div>
	</div>

	<!-- teksto slaideris -->
	<div class="slaideris">
		<div class="slideshow-container">
            <div class="mySlides fade">
            	<img src="img/header3-bg.jpg" alt="Karys su kirvius. Fone vyksta kova" style="width:100%">
                <div class="text">Daugel tame krašte pilių buvo, ir kiekvienoje jų – karalius.</div>
            </div>
            <div class="mySlides fade">
            	<img src="img/header2-bg.jpg" alt="Kariai su kirviais pasiruošę kovai" style="width:100%">
                <div class="text">Krašto viduryje, kurio pikti priešai dar nebuvo pasiekę, susirinko visų kilčių vyrai, bendros bėdos aptarti.</div>
            </div>
            <div class="mySlides fade">
            	<img src="img/header4-bg.jpg" alt="Išsirikiavę Leitgirio klubo nariai" style="width:100%">
                <div class="text">Šimtametėje girioje, kur, anot senų padavimų visi dievai gyvena, suradę karšinčių ąžuolą, vyrai prisiekė saugoti bočių palikimą...</div>
            </div>
            <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
            <a class="next" onclick="plusSlides(1)">&#10095;</a>
        </div>
        <br>
        <div style="text-align:center">
          <span class="dot" onclick="currentSlide(1)"></span> 
          <span class="dot" onclick="currentSlide(2)"></span> 
          <span class="dot" onclick="currentSlide(3)"></span> 
        </div>
	</div>
	 
	<!--kalendorius-->
	<div class="calendar" id="calendar">
	 	<div class="clnd-box">
	 		<figure>
				<img src="img/mgp.jpg" alt="Leitigirio nariai prie medinės tvirtovės">
			</figure>
			<div class="btn-clnd"><a href="matysite.php" class="btn-sekti">Mus galite pamatyti</a></div>
			<div class="line"></div>
		</div>
	</div>
	<div class="calendar2">
		<div class="clnd-box">
			<figure>
				<img src="img/prk.jpg" alt="Leitgiris filmuojasi filmui">
			</figure>
			<div class="btn-clnd"><a href="prk.php" class="btn-sekti">Renginių metraštis</a></div>
			<div class="line"></div>
		</div>
	</div>

	<!-- kontaktai -->
	<div class="contacts" id="kontaktai">
		<div class="forma">
			<h2>Turite klausimų?</h2>
			<p class="text-muted">Susisiekite su mumis Jums rūpimais klausimais ir mes nedelsiant atsakysime.</p>
			<form id="contact" action="src/app.php" method="post">
			    <input type="text" name="vardas" placeholder="Jūsų vardas*" required >
			    <input type="email" name="email" placeholder="Jūsų el. pašto adresas*" required>
			    <textarea name="message" placeholder="Jūsų žinutė"></textarea>
			    <input name="submit" type="submit" id="contact-submit" value="Siųsti">
			</form>
		</div>
	</div>
	<div class="adress">
		<div class="adresas">
			<h2><i class="fas fa-map-marker-alt"></i>Adresas</h2>
			<p class="text-muted">Bendorėlių 1-oji al. 48, LT-14196, Bendoriai, Vilniaus r. sav.</p>
		</div>
		<div class="email">
			<h2><i class="fas fa-envelope"></i>E - paštas</h2>
			<p class="text-muted">info<i class="fas fa-at"></i>leitgiris.lt</p>
		</div>
		<div class="phone">
			<h2><i class="fas fa-mobile-alt"></i>Telefono Nr.</h2>
			<a href="tel:+37069941231"><p class="text-muted">+370 699 41231</p></a>
		</div>
		<div class="fb">
			<a href="https://www.facebook.com/Leitgiris"><i class="fab fa-facebook fa-3x"></i></a>
		</div>
	</div>

<?php
include_once('footer.php');
?>