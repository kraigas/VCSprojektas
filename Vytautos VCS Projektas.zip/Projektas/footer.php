	<footer class="footer">
		<div> &copy; Leitgiris <?php echo date('Y'); ?></div>
	</footer>

	<!-- jQuery Scripts -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<!-- Mano Scripts -->
	<script src="js/custom.js"></script>

</body>
</html>