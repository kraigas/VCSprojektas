<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Leitgiris</title>
	<meta name="description" content="Gyvosios istorijos klubas - Leitgiris. Istorinė rekonstrukcija: karyba, amatai ir edukacijos">
    <!-- Custom CSS -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <!-- Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'> 
    <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>
    <!-- Font awesome -->
    <script src="https://kit.fontawesome.com/c2456d7847.js" crossorigin="anonymous"></script>

</head>
<body class="grid-container wraper">
	<header id="shrink">
		<div class="Navbar">
			<div class="logo" id="logo"><a href="#top">Leitgiris</a></div>
			<div class="Navbar__Link Navbar__Link-toggle">
				<i class="fas fa-bars fa-2x"></i>
			</div>

			<nav class="Navbar__Items Navbar__Items--right">
				<div class="Navbar__Link">
					<a href="#apie" onclick="classToggle()">Apie mus</a>
				</div>
				<div class="Navbar__Link">
					<a href="nariai.php" onclick="classToggle()">Nariai</a>
				</div>
				<div class="Navbar__Link">
					<a href="#calendar" onclick="classToggle()">Kalendorius</a>
				</div>
				<div class="Navbar__Link">
					<a href="#kontaktai" onclick="classToggle()">Kontaktai</a>
				</div>
			</nav>
		</div>
	</header>