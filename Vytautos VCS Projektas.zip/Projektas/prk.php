<?php
include_once 'headeroff.php';
ini_set('display_errors', '1');
//include('src/conn.php');
require __DIR__ . '/src/conn.php';
?>

<section class="kalnedorius">

    <h2>Praėjusių renginių metraštis</h2>
    <table>
        <tr class="tr-header">
            <th style="width: 18%;">Data</th>
            <th>Renginys</th>
            <th style="width: 18%;">Nuotraukų galerija</th>
        </tr>
    
    <?php
    $date_now = date('Y-m-d');
    $rows['Data_Iki'] = null;
    $rows['Ren_Foto_Link'] = null;
    while ($rows = mysqli_fetch_assoc($result)) {
        if ($rows['Data_Nuo'] < $date_now) {
            if ($rows['Data_Iki'] === null && $rows['Ren_Foto_Link'] === null) {
                ?>
                <tr>
                    <td><?php echo $rows['Data_Nuo']; ?></td>
                    <td class="td-ren"><?php echo $rows['Ren_Pavadinimas'];?></td>
                    <td></td>
                </tr>
                <?php
            } else {
                if ($rows['Data_Iki'] === null && $rows['Ren_Foto_Link'] != null) {
                    echo
                    '<tr>
                        <td>' . $rows["Data_Nuo"] . '</td>
                        <td class="td-ren">' . $rows["Ren_Pavadinimas"] . '</td>
                        <td><a href="' . $rows["Ren_Foto_Link"] . '" target="_blank"><i class="far fa-images fa-2x"></i></a></td>
                    </tr>';
                    
                } else {
                    if ($rows['Data_Iki'] != null && $rows['Ren_Foto_Link'] === null) {
                        ?>
                        <tr>
                            <td><?php echo $rows['Data_Nuo'] . ' - ' . $rows['Data_Iki']; ?></td>
                            <td class="td-ren"><?php echo $rows['Ren_Pavadinimas'];?></td>
                            <td></td>
                        </tr>
                        <?php
                    } else {
                        if ($rows['Data_Iki'] != null && $rows['Ren_Foto_Link'] != null) {
                            echo
                            '<tr>
                                <td>' . $rows["Data_Nuo"] . ' - ' . $rows["Data_Iki"] . '</td>
                                <td class="td-ren">' . $rows["Ren_Pavadinimas"] . '</td>
                                <td><a href="' . $rows["Ren_Foto_Link"] . '" target="_blank"><i class="far fa-images fa-2x"></i></a></td>
                            </tr>';
                        }
                    }
                }
            }
        }
    }
?>
</table>
</section>

<?php
include_once 'footer.php';
?>