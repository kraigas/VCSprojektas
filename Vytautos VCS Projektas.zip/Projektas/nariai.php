<?php
ini_set('display_errors', '1');
include_once 'headeroff.php';
?>

<section class="team">Gyvosios istorijos klubo „Leitgiris″ nariai</section>

    <div class="zalcius member">
        <div class="team-photo">
            <img src="img/team/Zalcius.jpg" alt="Klubo seniūnas Žalčius">
            <div class="small-logo-tr"></div>
            <h2>Žalčius</h2>
            <p class="text-muted">Seniūnas</p>
        </div>
    </div>
    <div class="elena member">
        <div class="team-photo">
            <img src="img/team/Elena.jpg" alt="Tarybos narė Elena">
            <div class="small-logo-tr"></div>
            <h2>Elena</h2>
            <p class="text-muted">Tarybos narė</p>
        </div>
    </div>
    <div class="mindaugas member">
        <div class="team-photo">
            <img src="img/team/Mindaugas.jpg" alt="Tarybos narys Mindaugas">
            <div class="small-logo-tr"></div>
            <h2>Mindaugas</h2>
            <p class="text-muted">Tarybos narys</p>
        </div>
    </div>
    <div class="deima member">
        <div class="team-photo">
            <img src="img/team/Deima.jpg" alt="Narė Deima">
            <div class="small-logo"></div>
            <h2>Deima</h2>
            <p class="text-muted">Narė</p>
        </div>
    </div>
    <div class="gedas member">
        <div class="team-photo">
            <img src="img/team/Gedas.jpg" alt="Narys Gedas">
            <div class="small-logo"></div>
            <h2>Gediminas</h2>
            <p class="text-muted">Narys</p>
        </div>
    </div>
    <div class="gerda member">
        <div class="team-photo">
            <img src="img/team/Gerda.jpg" alt="Narė Gerda">
            <div class="small-logo"></div>
            <h2>Gerda</h2>
            <p class="text-muted">Narė</p>
        </div>
    </div>
    <div class="kuosa member">
        <div class="team-photo">
            <img src="img/team/Kuosa.jpg" alt="Narys Kuosa">
            <div class="small-logo"></div>
            <h2>Kuosa</h2>
            <p class="text-muted">Narys</p>
        </div>
    </div>
    <div class="linas member">
        <div class="team-photo">
            <img src="img/team/Linas.jpg" alt="Narys Linas">
            <div class="small-logo"></div>
            <h2>Linas</h2>
            <p class="text-muted">Narys</p>
        </div>
    </div>
    <div class="martynas member">
        <div class="team-photo">
            <img src="img/team/Martynas.jpg" alt="Narys Martynas">
            <div class="small-logo"></div>
            <h2>Martynas</h2>
            <p class="text-muted">Narys</p>
        </div>
    </div>
    <div class="nalsius member">
        <div class="team-photo">
            <img src="img/team/Nalsius.jpg" alt="Narys Nalšius">
            <div class="small-logo"></div>
            <h2>Nalšius</h2>
            <p class="text-muted">Narys</p>
        </div>
    </div>
    <div class="raminta member">
        <div class="team-photo">
            <img src="img/team/Raminta.jpg" alt="Narė Raminta">
            <div class="small-logo"></div>
            <h2>Raminta</h2>
            <p class="text-muted">Narė</p>
        </div>
    </div>
    <div class="siga member">
        <div class="team-photo">
            <img src="img/team/Siga.jpg" alt="Narė Siga">
            <div class="small-logo"></div>
            <h2>Siga</h2>
            <p class="text-muted">Narė</p>
        </div>
    </div>
    <div class="skirmantas member">
        <div class="team-photo">
            <img src="img/team/Skirmantas.jpg" alt="Narys Skirmantas">
            <div class="small-logo"></div>
            <h2>Skirmantas</h2>
            <p class="text-muted">Narys</p>
        </div>
    </div>
    <div class="vytas member">
        <div class="team-photo">
            <img src="img/team/Vytas.jpg" alt="Narys Vytas">
            <div class="small-logo"></div>
            <h2>Vytas</h2>
            <p class="text-muted">Narys</p>
        </div>
    </div>
    <div class="marija member">
        <div class="team-photo seima">
            <img src="img/team/Marija.jpg" alt="Šeiminykštė Marija">
            <div class="small-logo seima"></div>
            <h2>Marija</h2>
            <p class="text-muted">Šeiminykštė</p>
        </div>
    </div>
    <div class="raimis member">
        <div class="team-photo seima">
            <img src="img/team/Raimis.jpg" alt="Šeiminykštis Raimis">
            <div class="small-logo seima"></div>
            <h2>Raimis</h2>
            <p class="text-muted">Šeiminykštis</p>
        </div>
    </div>
    <div class="visgirdas member">
        <div class="team-photo seima">
            <img src="img/team/Visgirdas.jpg" alt="Šeiminykštis Visgirdas">
            <div class="small-logo seima"></div>
            <h2>Visgirdas</h2>
            <p class="text-muted">Šeiminykštis</p>
        </div>
    </div>
    <div class="vytenis member">
        <div class="team-photo seima">
            <img src="img/team/Vytenis.jpg" alt="Šeiminykštis Vytenis">
            <div class="small-logo seima"></div>
            <h2>Vytenis</h2>
            <p class="text-muted">Šeiminykštis</p>
        </div>
    </div>
    <div class="žvirblis member">
        <div class="team-photo seima">
            <img src="img/team/Zvirblis.jpg" alt="Šeiminykštis Žvirblis">
            <div class="small-logo seima"></div>
            <h2>Žvirblis</h2>
            <p class="text-muted">Šeiminykštis</p>
        </div>
    </div>


<?php
include_once 'footer.php';
?>