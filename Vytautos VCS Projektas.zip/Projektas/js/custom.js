/* HEADER EXPAND AND SHRINK && TO TOP BUTTON (DIS)APEAR START */ 

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 70 || document.documentElement.scrollTop > 70) {
    document.getElementById("shrink").style.height = "70px";
    document.getElementById("shrink").style.backgroundColor = "#222";
    document.getElementById("logo").style.fontSize = "3em";
    document.getElementById("logo").style.paddingTop = "15px";

  } else {
    document.getElementById("shrink").style.height = "100px";
    document.getElementById("shrink").style.background = "transparent";
    document.getElementById("logo").style.fontSize = "4em";
    document.getElementById("logo").style.paddingTop = "25px";
      if (x.matches) {
      document.getElementById("shrink").style.backgroundColor = "#222";
    } else {
      document.getElementById("shrink").style.backgroundColor = "#transparent";
      if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        mybutton.style.display = "block";
      } else {
        mybutton.style.display = "none";
      }
    }
  }
}

let x = window.matchMedia("(max-width: 768px)");
let mybutton = document.getElementById("to-top");

/* HEADER EXPAND AND SHRINK && TO TOP BUTTON (DIS)APEAR END */ 

/* NAV TOGGLE START */

const navs = document.querySelectorAll('.Navbar__Items');

function classToggle() {
  navs.forEach(nav => nav.classList.toggle('Navbar__ToggleShow'));
}

document.querySelector('.Navbar__Link-toggle').addEventListener('click', classToggle);

/* NAV TOGGLE END */

$(document).ready(function() {

  /* SCROL TO TOP START */

  $("a[href='#top']").click(function() {
      $("html, body").animate({ scrollTop: 0 }, "slow");
      return false;
  });

  /* SCROL TO TOP END */

  /* SCROLL TO ID START*/

  $("a[href^='#']").click(function(e) {
    e.preventDefault();
    
    let position = $($(this).attr("href")).offset().top-50;

    $("body, html").animate({
      scrollTop: position
    } /* speed */ );
  });

  /* SCROLL TO ID END*/

  /* OPEN/CLOSE MODAL START */

  $('.modalBtn').on('click', function() {
    $(this).next('.modal').css('display', 'block');
  });
  $('.close').on('click', function() {
    $(this).closest('.modal').css('display', 'none');
  });

  let stilius = $('.modal').css('display');

    $('.modal').on('click', function (e) {
      if ($(e.target).is('.modal')) {
          $('.modal').css('display', 'none');
      }
    });

  /* OPEN/CLOSE MODAL END */

  /* COUNT START */

  $('.count').each(function () {
    $(this).prop('Counter',0).animate({
      Counter: $(this).text()
    }, {
      duration: 4000,
      easing: 'swing',
      step: function (now) {
        $(this).text(Math.ceil(now));
      }
    });
  });

  /* COUNT END */

  /* FILLING LINE START */

  $('.clnd-box').hover(function(){
    $(this).find('.line').css('background-position', 'left bottom');
  }, function() {
    $(this).find('.line').css('background-position', '');
  });

  /* FILLING LINE END */

});


/* START OF SLIDESHOW */

let slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1} 
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none"; 
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block"; 
  dots[slideIndex-1].className += " active";
}

/* END OF SLIDESHOW */